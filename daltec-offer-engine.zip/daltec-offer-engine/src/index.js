const fs = require('fs');
const path = require('path');
const { buildOfferFromText } = require('./engine');

async function main() {
  const inputPath = process.argv[2];
  if (!inputPath) {
    console.error('Usage: node src/index.js <eduard-request-text-file>');
    process.exit(1);
  }

  const raw = fs.readFileSync(path.resolve(inputPath), 'utf8');
  const sampleInventory = [
    {
      Produktcode: '3318-4-3O3-3563-N',
      Typ: 'Dreiseiten-Kipper',
      Bruttopreis: 6312.5,
      Nettopreis: 5000,
      Verfügbarkeit: 'Lagernd'
    },
    {
      Produktcode: 'BS-3318-70-OB',
      Titel: 'Pendelbare Aufsatzbordwände (70 cm hoch)',
      Typ: 'Aufsatzbordwände',
      Bruttopreis: 1079.17,
      Nettopreis: 800,
      Verfügbarkeit: 'Lagernd'
    }
  ];
  const result = await buildOfferFromText(raw, { inventoryRows: sampleInventory });
  console.log(JSON.stringify({
    lead: result.parsed.lead,
    articleIds: result.parsed.articleIds,
    availabilityText: result.offer.availabilityText,
    summary: result.offer.summary,
    draft: { to: result.draft.to, subject: result.draft.subject, humanReviewRequired: result.draft.humanReviewRequired },
    crmTables: {
      lead: result.crm.leadPayload,
      quote: result.crm.quotePayload,
      quoteItems: result.crm.quoteItemsPayload.length,
      emailEvent: result.crm.emailEventPayload
    }
  }, null, 2));
}

if (require.main === module) {
  main().catch(error => {
    console.error(error);
    process.exit(1);
  });
}

module.exports = require('./engine');
