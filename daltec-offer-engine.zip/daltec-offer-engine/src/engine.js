const { parseEduardRequest } = require('./eduardParser');
const { enrichOffer } = require('./priceEngine');
const { renderOfferHtml } = require('./htmlTemplate');
const { buildCrmPayload, finalizeDraftEvent } = require('./crmPayload');

async function buildOfferFromText(rawText, { inventoryRows = [], pricing = {}, supabaseOk = true } = {}) {
  const parsed = parseEduardRequest(rawText);
  const offer = enrichOffer(parsed, inventoryRows, { ...pricing, supabaseOk });
  const rendered = renderOfferHtml(offer);
  const crm = buildCrmPayload(offer, rendered);

  return {
    parsed,
    offer,
    rendered,
    crm,
    draft: {
      to: rendered.emailTo,
      subject: rendered.emailSubject,
      html: rendered.emailHtml,
      text: rendered.emailText,
      humanReviewRequired: true
    }
  };
}

async function runProduction(rawText, { supabaseClient, gmailClient, pricing = {} }) {
  const parsed = parseEduardRequest(rawText);
  let inventoryRows = [];
  let supabaseOk = true;

  try {
    inventoryRows = await supabaseClient.getInventoryByCodes(parsed.articleIds);
  } catch (error) {
    supabaseOk = false;
  }

  const built = await buildOfferFromText(rawText, { inventoryRows, pricing, supabaseOk });
  await supabaseClient.persistCrm(built.crm);
  const draftResponse = await gmailClient.createDraft({
    to: built.rendered.emailTo,
    subject: built.rendered.emailSubject,
    html: built.rendered.emailHtml,
    text: built.rendered.emailText
  });
  const finalEvent = finalizeDraftEvent(built.crm.emailEventPayload, draftResponse);
  await supabaseClient.upsert('email_events', finalEvent);
  return { ...built, gmailDraft: draftResponse, emailEvent: finalEvent };
}

module.exports = { buildOfferFromText, runProduction };
