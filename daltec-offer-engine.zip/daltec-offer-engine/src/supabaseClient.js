function requireEnv(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing environment variable: ${name}`);
  return value;
}

function supabaseHeaders() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!key) throw new Error('Missing SUPABASE_SERVICE_ROLE_KEY or SUPABASE_ANON_KEY');
  return {
    apikey: key,
    Authorization: `Bearer ${key}`,
    'Content-Type': 'application/json',
    Accept: 'application/json'
  };
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

class SupabaseClient {
  constructor({ url = process.env.SUPABASE_URL, timeoutMs = 8000 } = {}) {
    this.url = String(url || requireEnv('SUPABASE_URL')).replace(/\/$/, '');
    this.timeoutMs = timeoutMs;
  }

  async getInventoryByCodes(codes) {
    if (!codes?.length) return [];
    const quoted = codes.map(code => `"${String(code).replace(/"/g, '')}"`).join(',');
    const endpoint = `${this.url}/rest/v1/inventory?select=Produktcode,Typ,Bruttopreis,Nettopreis,Verf%C3%BCgbarkeit&Produktcode=in.(${encodeURIComponent(quoted)})`;
    const response = await fetchWithTimeout(endpoint, { headers: supabaseHeaders() }, this.timeoutMs);
    if (!response.ok) throw new Error(`Supabase inventory failed: ${response.status} ${await response.text()}`);
    return response.json();
  }

  async upsert(table, payload) {
    const endpoint = `${this.url}/rest/v1/${table}`;
    const response = await fetchWithTimeout(endpoint, {
      method: 'POST',
      headers: {
        ...supabaseHeaders(),
        Prefer: 'resolution=merge-duplicates,return=representation'
      },
      body: JSON.stringify(Array.isArray(payload) ? payload : [payload])
    }, this.timeoutMs);
    if (!response.ok) throw new Error(`Supabase upsert ${table} failed: ${response.status} ${await response.text()}`);
    return response.json();
  }

  async persistCrm(crm) {
    await this.upsert('leads', crm.leadPayload);
    await this.upsert('quotes', crm.quotePayload);
    if (crm.quoteItemsPayload.length) await this.upsert('quote_items', crm.quoteItemsPayload);
    return true;
  }
}

module.exports = { SupabaseClient, fetchWithTimeout };
