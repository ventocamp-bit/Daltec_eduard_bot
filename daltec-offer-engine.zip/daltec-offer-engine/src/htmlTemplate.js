function escapeHtml(value = '') {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function euro(value) {
  return new Intl.NumberFormat('de-AT', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2
  }).format(Number(value || 0));
}

function salutation(lead) {
  return lead?.lastName
    ? `Sehr geehrter Herr/Frau ${escapeHtml(lead.lastName)},`
    : 'Sehr geehrte Damen und Herren,';
}

function plainTextFromHtml(html) {
  return html
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function renderOfferHtml(offer) {
  const lead = offer.lead || {};
  const rows = offer.enrichedRows || [];
  const s = offer.summary || {};
  const customerLabel = [lead.firstName, lead.lastName].filter(Boolean).join(' ') || 'Ihr Eduard-Anhänger';
  const statusLabel = offer.allMainAvailable ? 'lagernd / sofort verfügbar' : 'Fahrzeug aus Vorbestellung';
  const rowHtml = rows.map(row => `
    <tr>
      <td style="border:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;font-family:Calibri,Arial,sans-serif;">${escapeHtml(row.artikelbezeichnung)}</td>
      <td align="right" style="border:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;font-family:Calibri,Arial,sans-serif;white-space:nowrap;">${euro(row.uvpNetto)}</td>
      <td align="right" style="border:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;font-family:Calibri,Arial,sans-serif;color:#d6232a;font-style:italic;white-space:nowrap;">${euro(row.rabattNetto)}</td>
      <td align="right" style="border:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;font-family:Calibri,Arial,sans-serif;white-space:nowrap;">${euro(row.angebotNetto)}</td>
    </tr>`).join('');

  const tableHtml = `
    <table role="presentation" cellspacing="0" cellpadding="0" style="border-collapse:collapse;width:760px;max-width:100%;font-family:Calibri,Arial,sans-serif;color:#222;">
      <tr>
        <td style="border:1px solid #d9d9d9;background:#ffc000;padding:4px 6px;font-size:14pt;font-weight:bold;">${escapeHtml(customerLabel)} - ${escapeHtml(statusLabel)}</td>
        <td style="border:1px solid #d9d9d9;background:#d9d9d9;padding:4px 6px;font-size:14pt;font-weight:bold;text-align:center;">UVP</td>
        <td style="border:1px solid #d9d9d9;background:#d9d9d9;padding:4px 6px;font-size:14pt;font-weight:bold;font-style:italic;text-align:center;">Rabatt</td>
        <td style="border:1px solid #d9d9d9;background:#d9d9d9;padding:4px 6px;font-size:14pt;font-weight:bold;text-align:center;">Angebot</td>
      </tr>
      ${rowHtml}
      <tr>
        <td style="border-top:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;">Gesamt netto</td>
        <td align="right" style="border-top:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;white-space:nowrap;">${euro(s.totalUvpNetto)}</td>
        <td align="right" style="border-top:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;color:#d6232a;font-style:italic;white-space:nowrap;">${euro(s.totalRabattNetto)}</td>
        <td align="right" style="border-top:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;white-space:nowrap;">${euro(s.totalAngebotNetto)}</td>
      </tr>
      <tr>
        <td style="border-top:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;">20% Mehrwertsteuer</td>
        <td align="right" style="border-top:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;white-space:nowrap;">${euro(s.vatUvp)}</td>
        <td align="right" style="border-top:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;color:#d6232a;font-style:italic;white-space:nowrap;">${euro(s.vatRabatt)}</td>
        <td align="right" style="border-top:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;white-space:nowrap;">${euro(s.vatAngebot)}</td>
      </tr>
      <tr>
        <td style="border-top:2px solid #222;border-bottom:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;font-weight:bold;">Gesamt Brutto</td>
        <td align="right" style="border-top:2px solid #222;border-bottom:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;font-weight:bold;white-space:nowrap;">${euro(s.totalUvpBrutto)}</td>
        <td align="right" style="border-top:2px solid #222;border-bottom:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;font-weight:bold;color:#d6232a;font-style:italic;white-space:nowrap;">${euro(s.totalRabattBrutto)}</td>
        <td align="right" style="border-top:2px solid #222;border-bottom:2px solid #222;border-left:1px solid #d9d9d9;border-right:1px solid #d9d9d9;padding:4px 6px;font-size:12pt;font-weight:bold;white-space:nowrap;">${euro(s.totalAngebotBrutto)}</td>
      </tr>
    </table>`;

  const html = `<!doctype html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body lang="DE-AT" style="word-wrap:break-word;background:#ffffff;margin:0;padding:0;">
<div style="font-family:Aptos,Calibri,Arial,sans-serif;font-size:11pt;color:#000;line-height:1.35;">
  <p style="margin:0 0 14px 0;">${salutation(lead)}</p>
  <p style="margin:0 0 12px 0;">vielen Dank für Ihre Anfrage zu einem Eduard Anhänger.</p>
  <p style="margin:0 0 12px 0;">${escapeHtml(offer.availabilityText)}</p>
  <p style="margin:0 0 12px 0;">Wir können Ihnen die angefragte Konfiguration mit einem Rabatt von ${euro(s.totalRabattBrutto)} statt ${euro(s.totalUvpBrutto)} zu einem Preis von <strong>${euro(s.totalAngebotBrutto)}</strong> inklusive 20% Mehrwertsteuer ab 2111 Harmannsdorf anbieten.</p>
  <div style="margin:16px 0 18px 0;">${tableHtml}</div>
  <p style="margin:0 0 12px 0;">Für Rückfragen oder eine kurze telefonische Besprechung erreichen Sie mich direkt unter <strong>+43 676 40 45 197</strong>. Gerne bin ich jederzeit für Sie erreichbar.</p>
  <p style="margin:0 0 14px 0;">BG Lukas Mitter</p>
  <p style="margin:0 0 8px 0;"><strong style="font-family:'Arial Narrow',Arial,sans-serif;color:#1F497D;font-size:10pt;">Lukas Mitter, MSc</strong></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Daltec GmbH</p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#242424;">Esaromstr. 5 <span style="color:#1F497D;">(Ecke Bahnhofplatz)</span></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">2111 Harmannsdorf - Rückersdorf</p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Büro: <span style="color:#242424;">+43 676 777 18 00</span></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Mob: <span style="color:#242424;">+43 676 40 45 197</span></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Email: <a href="mailto:lukas@daltec.at" style="color:#467886;">lukas@daltec.at</a></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Website: <a href="https://www.daltec.at/" style="color:#467886;">www.daltec.at</a></p>
</div>
</body>
</html>`;

  return {
    emailTo: lead.email,
    emailSubject: 'Daltec - Angebot via EDUARD-Konfigurator',
    emailHtml: html,
    emailText: plainTextFromHtml(html)
  };
}

module.exports = { renderOfferHtml, euro, plainTextFromHtml };
