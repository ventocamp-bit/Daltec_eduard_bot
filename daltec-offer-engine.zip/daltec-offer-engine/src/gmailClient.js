function base64Url(value) {
  return Buffer.from(value, 'utf8')
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function buildMimeMessage({ to, from, subject, html, text }) {
  const boundary = `daltec_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const headers = [
    `To: ${to}`,
    from ? `From: ${from}` : null,
    `Subject: =?UTF-8?B?${Buffer.from(subject, 'utf8').toString('base64')}?=`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`
  ].filter(Boolean).join('\r\n');

  return `${headers}\r\n\r\n` +
    `--${boundary}\r\nContent-Type: text/plain; charset="UTF-8"\r\n\r\n${text || ''}\r\n\r\n` +
    `--${boundary}\r\nContent-Type: text/html; charset="UTF-8"\r\n\r\n${html || ''}\r\n\r\n` +
    `--${boundary}--`;
}

class GmailClient {
  constructor({ accessToken = process.env.GMAIL_ACCESS_TOKEN, userId = 'me' } = {}) {
    if (!accessToken) throw new Error('Missing GMAIL_ACCESS_TOKEN');
    this.accessToken = accessToken;
    this.userId = userId;
  }

  async createDraft({ to, from, subject, html, text }) {
    const mime = buildMimeMessage({ to, from, subject, html, text });
    const response = await fetch(`https://gmail.googleapis.com/gmail/v1/users/${this.userId}/drafts`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message: { raw: base64Url(mime) } })
    });
    if (!response.ok) throw new Error(`Gmail draft failed: ${response.status} ${await response.text()}`);
    return response.json();
  }
}

module.exports = { GmailClient, buildMimeMessage, base64Url };
