function round2(value) {
  return Math.round((Number(value || 0) + Number.EPSILON) * 100) / 100;
}

function toNumber(value) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value === 'number') return value;
  const normalized = String(value).replace(/\./g, '').replace(',', '.').replace(/[^0-9.-]/g, '');
  const n = Number(normalized);
  return Number.isFinite(n) ? n : null;
}

function normalizeCode(code) {
  return String(code || '').trim().toUpperCase();
}

function normalizeProductName(value = '') {
  return String(value)
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function statusOfInventory(row) {
  const raw = row?.Verfügbarkeit ?? row?.Verfuegbarkeit ?? row?.verfuegbarkeit ?? row?.availability;
  return String(raw || '').trim().toLowerCase() === 'lagernd' ? 'Lagernd' : 'Nicht Lagernd';
}

function firstDefined(...values) {
  return values.find(value => value !== undefined && value !== null && String(value).trim() !== '');
}

function enrichOffer(parsed, inventoryRows, options = {}) {
  const rabattRate = Number(options.rabattRate ?? process.env.DALTEC_RABATT_RATE ?? 0.13);
  const minMarginRate = Number(options.minMarginRate ?? process.env.DALTEC_MIN_MARGIN_RATE ?? 0.08);
  const vatRate = Number(parsed.totals?.vatRate ?? options.vatRate ?? process.env.DALTEC_VAT_RATE ?? 0.2);
  const supabaseOk = options.supabaseOk !== false && Array.isArray(inventoryRows);

  const byCode = new Map();
  const byName = new Map();
  for (const row of inventoryRows || []) {
    const code = normalizeCode(row.Produktcode || row.produktcode);
    if (code) byCode.set(code, row);
    const names = [
      row.Titel,
      row.titel,
      row.Artikelbezeichnung,
      row.artikelbezeichnung,
      row.produkt_name_normalisiert
    ].filter(Boolean);
    for (const name of names) byName.set(normalizeProductName(name), row);
  }

  const enrichedRows = parsed.quoteRows.map((row, index) => {
    const match = byCode.get(normalizeCode(row.produktcode))
      || byName.get(normalizeProductName(row.artikelbezeichnung))
      || byName.get(normalizeProductName(row.produkt_name_normalisiert))
      || null;
    const inventoryStatus = supabaseOk && match ? statusOfInventory(match) : 'Nicht Lagernd';
    const dbBrutto = toNumber(firstDefined(match?.Bruttopreis, match?.['Bruttopreis (Konfigurator)'], match?.bruttopreis));
    const dbNetto = toNumber(firstDefined(match?.Nettopreis, match?.nettopreis));
    const uvpNetto = toNumber(row.sourceUvpNetto) ?? dbBrutto ?? dbNetto ?? 0;
    const rabattCandidate = round2(uvpNetto * rabattRate);
    const angebotCandidate = round2(uvpNetto - rabattCandidate);
    const minimumOffer = dbNetto ? round2(dbNetto * (1 + minMarginRate)) : 0;
    const angebotNetto = Math.max(angebotCandidate, minimumOffer);

    return {
      ...row,
      produktcode: row.produktcode || normalizeCode(match?.Produktcode),
      inventoryMatch: Boolean(match),
      inventoryStatus,
      inventoryTyp: match?.Typ || match?.typ || '',
      uvpNetto: round2(uvpNetto),
      rabattNetto: round2(uvpNetto - angebotNetto),
      angebotNetto: round2(angebotNetto),
      einkaufNetto: dbNetto,
      marginOk: !dbNetto || angebotNetto >= minimumOffer,
      isMainArticle: row.isMainArticle || index === 0
    };
  });

  const mainRows = enrichedRows.filter(row => row.isMainArticle);
  const allMainAvailable = supabaseOk && mainRows.length > 0 && mainRows.every(row => row.inventoryStatus === 'Lagernd');
  const availabilityText = allMainAvailable
    ? 'Gute Nachrichten: Dieses Modell (oder eine perfekte Alternative) haben wir aktuell auf Lager. Es ist sofort für Sie verfügbar!'
    : 'Dieses Modell fertigen wir exakt nach Ihren individuellen Wünschen an. Die aktuelle Lieferzeit beträgt ca. 4 bis 6 Wochen ab Bestellfreigabe.';

  const totalUvpNetto = round2(enrichedRows.reduce((sum, row) => sum + row.uvpNetto, 0));
  const totalRabattNetto = round2(enrichedRows.reduce((sum, row) => sum + row.rabattNetto, 0));
  const totalAngebotNetto = round2(enrichedRows.reduce((sum, row) => sum + row.angebotNetto, 0));
  const vatUvp = round2(totalUvpNetto * vatRate);
  const vatRabatt = round2(totalRabattNetto * vatRate);
  const vatAngebot = round2(totalAngebotNetto * vatRate);

  return {
    ...parsed,
    supabaseOk,
    enrichedRows,
    allMainAvailable,
    availabilityText,
    pricing: { rabattRate, minMarginRate, vatRate },
    summary: {
      totalUvpNetto,
      totalRabattNetto,
      totalAngebotNetto,
      vatRate,
      vatUvp,
      vatRabatt,
      vatAngebot,
      totalUvpBrutto: round2(totalUvpNetto + vatUvp),
      totalRabattBrutto: round2(totalRabattNetto + vatRabatt),
      totalAngebotBrutto: round2(totalAngebotNetto + vatAngebot)
    },
    guardrails: {
      missingInventoryMatches: enrichedRows.filter(row => !row.inventoryMatch).map(row => row.artikelbezeichnung),
      forcedFallbackNichtLagernd: !supabaseOk || mainRows.some(row => !row.inventoryMatch)
    }
  };
}

module.exports = { enrichOffer, round2 };
