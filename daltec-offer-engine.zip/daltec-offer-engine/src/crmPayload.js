const crypto = require('crypto');

function uuidFrom(input) {
  const hex = crypto.createHash('sha256').update(String(input)).digest('hex');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-4${hex.slice(13, 16)}-a${hex.slice(17, 20)}-${hex.slice(20, 32)}`;
}

function buildCrmPayload(offer, rendered, now = new Date().toISOString()) {
  const lead = offer.lead || {};
  const email = String(lead.email || '').toLowerCase();
  const quoteFingerprint = [
    email,
    lead.configUrl || '',
    (offer.articleIds || []).join('|'),
    offer.summary?.totalAngebotBrutto || ''
  ].join('|');

  const leadId = uuidFrom(`lead|${email}`);
  const quoteId = uuidFrom(`quote|${quoteFingerprint}`);
  const draftEventId = uuidFrom(`email_event|draft|${quoteId}`);

  const leadPayload = {
    id: leadId,
    created_at: now,
    updated_at: now,
    first_name: lead.firstName || '',
    last_name: lead.lastName || '',
    email,
    phone: lead.phone || '',
    address: lead.address || '',
    config_url: lead.configUrl || '',
    source: 'eduard_configurator',
    status: 'quote_draft_created'
  };

  const quotePayload = {
    id: quoteId,
    created_at: now,
    updated_at: now,
    lead_id: leadId,
    lead_email: email,
    email_subject: rendered.emailSubject,
    availability_status: offer.allMainAvailable ? 'Lagernd' : 'Nicht Lagernd',
    availability_text: offer.availabilityText,
    total_uvp_netto: offer.summary.totalUvpNetto,
    total_rabatt_netto: offer.summary.totalRabattNetto,
    total_angebot_netto: offer.summary.totalAngebotNetto,
    total_angebot_brutto: offer.summary.totalAngebotBrutto,
    vat_rate: offer.summary.vatRate,
    status: 'draft_created',
    sent_at: null,
    gmail_message_id: null,
    gmail_thread_id: null,
    config_url: lead.configUrl || '',
    raw_request_text: offer.rawText || '',
    guardrails: offer.guardrails
  };

  const quoteItemsPayload = offer.enrichedRows.map((row, index) => ({
    id: uuidFrom(`quote_item|${quoteId}|${index}|${row.produktcode || row.artikelbezeichnung}`),
    created_at: now,
    quote_id: quoteId,
    lead_id: leadId,
    position: index + 1,
    produktcode: row.produktcode || null,
    artikelbezeichnung: row.artikelbezeichnung,
    typ: row.inventoryTyp || null,
    inventory_status: row.inventoryStatus || 'Nicht Lagernd',
    uvp_netto: row.uvpNetto,
    rabatt_netto: row.rabattNetto,
    angebot_netto: row.angebotNetto,
    einkauf_netto: row.einkaufNetto || null,
    inventory_match: row.inventoryMatch,
    margin_ok: row.marginOk,
    is_main_article: row.isMainArticle
  }));

  const emailEventPayload = {
    id: draftEventId,
    created_at: now,
    lead_id: leadId,
    quote_id: quoteId,
    direction: 'outbound',
    status: 'draft_prepared',
    channel: 'gmail',
    gmail_message_id: null,
    gmail_thread_id: null,
    subject: rendered.emailSubject,
    body_text: rendered.emailText,
    body_html: rendered.emailHtml,
    classification: 'initial_quote',
    human_review_required: true
  };

  return { leadId, quoteId, draftEventId, leadPayload, quotePayload, quoteItemsPayload, emailEventPayload };
}

function finalizeDraftEvent(emailEventPayload, gmailDraftResponse) {
  return {
    ...emailEventPayload,
    status: 'draft_created_human_review',
    gmail_message_id: gmailDraftResponse?.message?.id || gmailDraftResponse?.id || null,
    gmail_thread_id: gmailDraftResponse?.message?.threadId || gmailDraftResponse?.threadId || null,
    gmail_raw_response: gmailDraftResponse || null
  };
}

module.exports = { buildCrmPayload, finalizeDraftEvent, uuidFrom };
