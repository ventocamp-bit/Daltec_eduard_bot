function decodeHtmlEntities(str = '') {
  return String(str)
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(parseInt(d, 10)));
}

function htmlToText(html = '') {
  return decodeHtmlEntities(String(html)
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n')
    .replace(/<\/tr>/gi, '\n')
    .replace(/<\/td>/gi, '\t')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<[^>]+>/g, ' '));
}

function normalizeText(raw = '') {
  const asText = /<[^>]+>/.test(String(raw)) ? htmlToText(raw) : decodeHtmlEntities(raw);
  return String(asText)
    .replace(/\r/g, '\n')
    .replace(/\u00a0/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function normalizeKey(value = '') {
  return String(value)
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function normalizeProductName(value = '') {
  return normalizeKey(value);
}

function cleanEmail(value = '') {
  const match = String(value).match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
  return match ? match[0].toLowerCase() : String(value).trim().toLowerCase();
}

function parseEuro(value) {
  if (value === undefined || value === null) return null;
  const raw = String(value).replace(/\s/g, '').replace(/€/g, '');
  const match = raw.match(/-?\d{1,3}(?:\.\d{3})*,\d{2}|-?\d+(?:[.,]\d+)?/);
  if (!match) return null;
  return Number(match[0].replace(/\./g, '').replace(',', '.'));
}

function formatCode(code) {
  return String(code || '').trim().replace(/\s+/g, '').toUpperCase();
}

function lineAfterLabel(lines, labels) {
  const keys = labels.map(normalizeKey);
  for (let i = 0; i < lines.length - 1; i += 1) {
    if (keys.includes(normalizeKey(lines[i]))) return lines[i + 1]?.trim() || '';
  }
  return '';
}

function optionalLineAfterLabel(lines, labels, stopLabels) {
  const value = lineAfterLabel(lines, labels);
  const stopKeys = stopLabels.map(normalizeKey);
  return stopKeys.includes(normalizeKey(value)) ? '' : value;
}

function extractConfigUrl(raw) {
  const match = String(raw).match(/https?:\/\/[^\s<>"')]+\/configurator\/[^\s<>"')]+/i);
  return match ? match[0] : '';
}

function extractArticleIds(text) {
  const codes = new Set();
  const section = text.split(/Artikelnummern Anhänger und Zubehör/i)[1] || text;
  const regex = /\b(?:[A-Z]{1,5}-)?\d{3,4}(?:-[A-Z0-9]{1,4}){2,}(?:-[A-Z0-9]+)?\b/g;
  let match;
  while ((match = regex.exec(section)) !== null) {
    const code = formatCode(match[0]);
    if (!/^\d{2}-\d{2}-\d{4}$/.test(code)) codes.add(code);
  }
  return Array.from(codes);
}

function extractQuoteRows(lines, articleIds) {
  const start = lines.findIndex(line => /preise.*kosten.*angepasst/i.test(line));
  const end = lines.findIndex(line => /Artikelnummern Anh/i.test(line));
  const body = lines.slice(start >= 0 ? start + 1 : 0, end >= 0 ? end : lines.length)
    .map(line => line.trim())
    .filter(Boolean);

  const rows = [];
  const totals = {};

  for (let i = 0; i < body.length - 1; i += 1) {
    const label = body[i];
    const next = body[i + 1];
    const price = parseEuro(next);
    if (price === null) continue;

    if (/^Preis$/i.test(label)) totals.netto = price;
    else if (/^Preis inkl\. MwSt$/i.test(label)) totals.brutto = price;
    else if (/^MwSt$/i.test(label)) totals.vatRate = parseEuro(next) ? parseEuro(next) / 100 : 0.2;
    else {
      rows.push({
        position: rows.length + 1,
        artikelbezeichnung: label,
        produkt_name_normalisiert: normalizeProductName(label),
        sourceUvpNetto: price,
        produktcode: rows.length === 0 ? (articleIds[0] || '') : '',
        isMainArticle: rows.length === 0
      });
    }
    i += 1;
  }

  return { rows, totals };
}

function parseEduardRequest(rawInput) {
  const raw = String(rawInput || '');
  const text = normalizeText(raw);
  const lines = text.split('\n').map(line => line.trim()).filter(Boolean);
  const articleIds = extractArticleIds(text);
  const { rows, totals } = extractQuoteRows(lines, articleIds);

  return {
    originalSubject: /Betreff:\s*(.+)/i.exec(text)?.[1]?.trim() || 'Neuer Lead – Angebot via EDUARD-Konfigurator',
    rawText: text,
    lead: {
      firstName: lineAfterLabel(lines, ['Vorname']),
      lastName: lineAfterLabel(lines, ['Nachname']),
      email: cleanEmail(lineAfterLabel(lines, ['E-mail-Adresse', 'E-Mail-Adresse', 'Email-Adresse'])),
      address: lineAfterLabel(lines, ['Adresse']),
      phone: lineAfterLabel(lines, ['Telefonnummer', 'Telefon']),
      remarks: optionalLineAfterLabel(lines, ['Fragen/Bemerkungen?', 'Fragen/Bemerkungen'], ['Konfiguration']),
      configUrl: extractConfigUrl(raw)
    },
    articleIds,
    quoteRows: rows,
    totals
  };
}

module.exports = {
  parseEduardRequest,
  parseEuro,
  normalizeProductName,
  normalizeText,
  formatCode
};
