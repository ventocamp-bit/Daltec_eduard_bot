const { renderOfferHtml } = require('./htmlTemplate');
const { uuidFrom } = require('./crmPayload');

function renderFollowUpDraft({ lead, quote, daysSinceQuote = 3 }) {
  const lastName = lead?.last_name || lead?.lastName || '';
  const email = lead?.email || quote?.lead_email || '';
  const salutation = lastName ? `Sehr geehrter Herr/Frau ${lastName},` : 'Sehr geehrte Damen und Herren,';
  const subject = 'Nachfrage Angebot';
  const html = `<!doctype html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body lang="DE-AT" style="word-wrap:break-word;background:#ffffff;margin:0;padding:0;">
<div style="font-family:Aptos,Calibri,Arial,sans-serif;font-size:11pt;color:#000;line-height:1.35;">
  <p>${salutation}</p>
  <p>wir haben Ihnen vor einigen Tagen ein Angebot zu einem Eduard Anhänger gesendet.</p>
  <p>Ich möchte auf diesem Wege nachfragen, ob wir Ihnen in dieser Angelegenheit noch weiter behilflich sein dürfen?</p>
  <p>Gerne bin ich auch telefonisch für Sie erreichbar.</p>
  <p>Beste Grüße<br>Lukas Mitter</p>
  <p style="margin:0 0 8px 0;"><strong style="font-family:'Arial Narrow',Arial,sans-serif;color:#1F497D;font-size:10pt;">Lukas Mitter, MSc</strong></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Daltec GmbH</p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#242424;">Esaromstr. 5 <span style="color:#1F497D;">(Ecke Bahnhofplatz)</span></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">2111 Harmannsdorf - Rückersdorf</p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Büro: <span style="color:#242424;">+43 676 777 18 00</span></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Mob: <span style="color:#242424;">+43 676 40 45 197</span></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Email: <a href="mailto:lukas@daltec.at" style="color:#467886;">lukas@daltec.at</a></p>
  <p style="margin:0;font-family:'Arial Narrow',Arial,sans-serif;font-size:8pt;color:#1F497D;">Website: <a href="https://www.daltec.at/" style="color:#467886;">www.daltec.at</a></p>
</div>
</body>
</html>`;

  const text = html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  return {
    to: email,
    subject,
    html,
    text,
    humanReviewRequired: true,
    reason: `follow_up_after_${daysSinceQuote}_days`
  };
}

function buildFollowUpEmailEvent({ lead, quote, draft, now = new Date().toISOString() }) {
  return {
    id: uuidFrom(`email_event|followup|${quote.id}|${now.slice(0, 10)}`),
    created_at: now,
    lead_id: lead.id,
    quote_id: quote.id,
    direction: 'outbound',
    status: 'draft_prepared',
    channel: 'gmail',
    gmail_message_id: null,
    gmail_thread_id: quote.gmail_thread_id || null,
    subject: draft.subject,
    body_text: draft.text,
    body_html: draft.html,
    classification: 'follow_up',
    human_review_required: true
  };
}

module.exports = { renderFollowUpDraft, buildFollowUpEmailEvent };
