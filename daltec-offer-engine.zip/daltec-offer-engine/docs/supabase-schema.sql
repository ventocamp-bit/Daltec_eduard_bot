create table if not exists public.leads (
  id uuid primary key,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  first_name text,
  last_name text,
  email text not null unique,
  phone text,
  address text,
  config_url text,
  source text not null default 'eduard_configurator',
  status text not null default 'new'
);

create table if not exists public.quotes (
  id uuid primary key,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  lead_id uuid references public.leads(id) on delete set null,
  lead_email text,
  email_subject text,
  availability_status text,
  availability_text text,
  total_uvp_netto numeric(12,2),
  total_rabatt_netto numeric(12,2),
  total_angebot_netto numeric(12,2),
  total_angebot_brutto numeric(12,2),
  vat_rate numeric(5,4) default 0.2,
  status text not null default 'draft_created',
  sent_at timestamptz,
  gmail_message_id text,
  gmail_thread_id text,
  config_url text,
  raw_request_text text,
  guardrails jsonb
);

create table if not exists public.quote_items (
  id uuid primary key,
  created_at timestamptz not null default now(),
  quote_id uuid not null references public.quotes(id) on delete cascade,
  lead_id uuid references public.leads(id) on delete set null,
  position integer,
  produktcode text,
  artikelbezeichnung text not null,
  typ text,
  inventory_status text not null default 'Nicht Lagernd',
  uvp_netto numeric(12,2),
  rabatt_netto numeric(12,2),
  angebot_netto numeric(12,2),
  einkauf_netto numeric(12,2),
  inventory_match boolean default false,
  margin_ok boolean default true,
  is_main_article boolean default false
);

create table if not exists public.email_events (
  id uuid primary key,
  created_at timestamptz not null default now(),
  lead_id uuid references public.leads(id) on delete set null,
  quote_id uuid references public.quotes(id) on delete set null,
  direction text not null,
  status text not null,
  channel text not null default 'gmail',
  gmail_message_id text,
  gmail_thread_id text,
  subject text,
  body_text text,
  body_html text,
  classification text,
  human_review_required boolean not null default true,
  gmail_raw_response jsonb
);

create index if not exists idx_quotes_status_created_at on public.quotes(status, created_at);
create index if not exists idx_email_events_thread on public.email_events(gmail_thread_id);
create index if not exists idx_quote_items_quote_id on public.quote_items(quote_id);
