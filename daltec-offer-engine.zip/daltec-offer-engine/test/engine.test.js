const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { parseEduardRequest } = require('../src/eduardParser');
const { buildOfferFromText } = require('../src/engine');
const { buildMimeMessage } = require('../src/gmailClient');
const { renderFollowUpDraft, buildFollowUpEmailEvent } = require('../src/followUp');

const fixture = fs.readFileSync(path.join(__dirname, '../fixtures/stefan-schleifer-request.txt'), 'utf8');

test('parses exact Eduard lead request fields', () => {
  const parsed = parseEduardRequest(fixture);

  assert.equal(parsed.lead.firstName, 'Stefan');
  assert.equal(parsed.lead.lastName, 'Schleifer');
  assert.equal(parsed.lead.email, 'stefan.schleifer96@gmail.com');
  assert.equal(parsed.lead.phone, '+436603106996');
  assert.equal(parsed.lead.remarks, '');
  assert.equal(parsed.articleIds[0], '3318-4-3O3-3563-N');
  assert.equal(parsed.quoteRows.length, 4);
  assert.equal(parsed.quoteRows[0].isMainArticle, true);
  assert.equal(parsed.quoteRows[0].sourceUvpNetto, 6312.5);
  assert.equal(parsed.totals.brutto, 8925);
});

test('uses Lagernd availability text when all main articles are available', async () => {
  const built = await buildOfferFromText(fixture, {
    inventoryRows: [{
      Produktcode: '3318-4-3O3-3563-N',
      Typ: 'Dreiseiten-Kipper',
      Bruttopreis: 6312.5,
      Nettopreis: 5000,
      Verfügbarkeit: 'Lagernd'
    }, {
      Produktcode: 'BS-3318-70-OB',
      Titel: 'Pendelbare Aufsatzbordwände (70 cm hoch)',
      Typ: 'Aufsatzbordwände',
      Bruttopreis: 1079.17,
      Nettopreis: 800,
      Verfügbarkeit: 'Lagernd'
    }]
  });

  assert.equal(built.offer.allMainAvailable, true);
  assert.match(built.offer.availabilityText, /Gute Nachrichten/);
  assert.match(built.rendered.emailHtml, /background:#ffc000/);
  assert.match(built.rendered.emailHtml, /UVP/);
  assert.match(built.rendered.emailHtml, /Rabatt/);
  assert.match(built.rendered.emailHtml, /Angebot/);
  assert.match(built.rendered.emailHtml, /Lukas Mitter, MSc/);
  assert.equal(built.crm.leadPayload.email, 'stefan.schleifer96@gmail.com');
  assert.equal(built.crm.quoteItemsPayload.length, 4);
  assert.equal(built.offer.enrichedRows[1].inventoryMatch, true);
  assert.equal(built.offer.enrichedRows[1].produktcode, 'BS-3318-70-OB');
  assert.equal(built.crm.emailEventPayload.human_review_required, true);
  assert.equal(built.offer.guardrails.forcedFallbackNichtLagernd, false);
});

test('falls back to Nicht Lagernd and 4 to 6 weeks on Supabase failure', async () => {
  const built = await buildOfferFromText(fixture, {
    inventoryRows: [],
    supabaseOk: false
  });

  assert.equal(built.offer.allMainAvailable, false);
  assert.match(built.offer.availabilityText, /4 bis 6 Wochen/);
  assert.equal(built.offer.enrichedRows[0].inventoryStatus, 'Nicht Lagernd');
  assert.equal(built.offer.guardrails.forcedFallbackNichtLagernd, true);
});

test('Gmail MIME draft is HTML capable and does not send', () => {
  const mime = buildMimeMessage({
    to: 'kunde@example.com',
    subject: 'Daltec - Angebot via EDUARD-Konfigurator',
    html: '<p>Test</p>',
    text: 'Test'
  });

  assert.match(mime, /multipart\/alternative/);
  assert.match(mime, /Content-Type: text\/html/);
  assert.match(mime, /To: kunde@example.com/);
});

test('builds follow-up as Gmail draft content with human review', () => {
  const lead = { id: 'lead-1', email: 'kunde@example.com', last_name: 'Raab' };
  const quote = { id: 'quote-1', lead_email: 'kunde@example.com', gmail_thread_id: 'thread-1' };
  const draft = renderFollowUpDraft({ lead, quote, daysSinceQuote: 3 });
  const event = buildFollowUpEmailEvent({ lead, quote, draft, now: '2026-05-13T12:00:00.000Z' });

  assert.equal(draft.subject, 'Nachfrage Angebot');
  assert.match(draft.html, /wir haben Ihnen vor einigen Tagen ein Angebot/);
  assert.equal(draft.humanReviewRequired, true);
  assert.equal(event.classification, 'follow_up');
  assert.equal(event.gmail_thread_id, 'thread-1');
  assert.equal(event.human_review_required, true);
});
