# Daltec Offer Engine

Testbare Code-Engine statt generischer n8n-JSON.

## Was sie macht

- Eduard-Konfigurator-Mail parsen.
- Artikelnummern gegen Supabase `inventory` matchen.
- Verfügbarkeit deterministisch bestimmen.
- Preise, Rabatt, MwSt und Angebotssummen berechnen.
- HTML-Angebot im Daltec/Lukas-Mitter-Stil rendern.
- CRM-Payloads für `leads`, `quotes`, `quote_items`, `email_events` bauen.
- Gmail-Draft erstellen, nicht automatisch senden.
- Follow-up-Drafts im Stil der Nachfrage-Mails vorbereiten.

## Human-in-the-loop

Gmail wird nur als Draft verwendet. Der Code sendet keine Kundenmail automatisch. Der Mensch prüft den Entwurf und klickt danach manuell in Gmail auf Senden.

## Tests

```bash
npm test
```

## Demo

```bash
npm run demo
```

## Produktive ENV

```bash
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=...
GMAIL_ACCESS_TOKEN=...
DALTEC_RABATT_RATE=0.13
DALTEC_MIN_MARGIN_RATE=0.08
DALTEC_VAT_RATE=0.20
```

## Datenbank

Vor produktiver Nutzung `docs/supabase-schema.sql` im Supabase SQL Editor ausführen.

Die bestehende Tabelle `inventory` muss enthalten:

- `Produktcode`
- `Typ`
- `Bruttopreis`
- `Nettopreis`
- `Verfügbarkeit`

## Follow-ups

`src/followUp.js` erzeugt nur Gmail-Draft-Inhalte und ein `email_events`-Payload. Auch Follow-ups werden nicht automatisch gesendet.

## Integrationsidee

Dieses Projekt kann n8n ersetzen oder von n8n nur noch als Webhook/HTTP-Service aufgerufen werden. Der kritische Teil liegt dann im getesteten Code, nicht in schwer testbarer Node-Konfiguration.
