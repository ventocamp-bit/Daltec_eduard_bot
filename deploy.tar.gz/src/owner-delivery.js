import { loadConfig } from './config.js';
import { createMailRuntime } from './mail-runtime.js';
import { appendOfferRunEvent, updateOfferRun } from './storage.js';
import { authConfig } from './auth.js';
import { createFeedbackToken } from './feedback-token.js';

export async function deliverRunDraftToOwner(run, settings, context = {}) {
  if (!run?.draft?.html_body && !run?.draft_html) {
    await appendOfferRunEvent(run.id, {
      event_type: 'owner_delivery_skipped',
      level: 'warning',
      message: 'No draft available for owner delivery'
    }, context);
    return { delivered: false, reason: 'draft_missing' };
  }

  const config = loadConfig();
  const effectiveConfig = {
    ...config,
    gmail: {
      ...config.gmail,
      to: settings.mail?.to || config.gmail.to,
      cc: config.gmail.cc,
      subject: settings.mail?.subject || config.gmail.subject
    }
  };
  const runtime = await createMailRuntime(effectiveConfig, context);
  const to = settings.mail?.to || config.gmail.to;
  const customerEmail = run.draft?.customer_email || run.summary?.customerEmail || run.customer_json?.email || '';
  const customerName = run.summary?.customerName || [run.customer_json?.first_name, run.customer_json?.last_name].filter(Boolean).join(' ');
  const subjectParts = ['[Review] Eduard'];
  if (customerName) subjectParts.push(customerName);
  if (customerEmail) subjectParts.push(customerEmail);
  const subject = subjectParts.join(' – ');
  
  const cleanHtml = buildCleanReviewTable(run);
  const html = wrapOwnerDraftWithFeedback(run, cleanHtml, config, settings, customerEmail);

  await runtime.sendHtmlMail(runtime.client, {
    to,
    cc: config.gmail.cc,
    subject,
    html
  });
  await updateOfferRun(run.id, {
    status: 'sent_to_owner',
    completed_at: new Date().toISOString(),
    summary: {
      ...(run.summary || {}),
      notes: `Sent by ${runtime.provider} owner adapter to ${to}`
    }
  }, context);
  await appendOfferRunEvent(run.id, {
    event_type: 'sent_to_owner',
    level: run.status === 'needs_review' ? 'warning' : 'info',
    message: `Draft sent to owner ${to}`,
    metadata: { to, cc: config.gmail.cc, provider: runtime.provider }
  }, context);
  return { delivered: true, provider: runtime.provider, to };
}

function wrapOwnerDraftWithFeedback(run, html, config, settings, customerEmail) {
  const baseUrl = String(config.app?.baseUrl || '').replace(/\/$/, '');
  if (!baseUrl) return html;
  const secret = authConfig().sessionSecret;
  const tenantId = run.dealer_id || settings.dealer?.id || 'daltec-local';
  const links = [
    ['sendable', 'Sendbar'],
    ['minor_correction', 'Korrektur n\u00f6tig']
  ].map(([rating, label]) => {
    const token = createFeedbackToken({ tenantId, runId: run.id, rating }, secret);
    const href = `${baseUrl}/feedback?token=${encodeURIComponent(token)}`;
    return `<a href="${href}" style="display:inline-block;margin:0 12px 8px 0;padding:12px 18px;border-radius:6px;text-decoration:none;font-family:Arial,sans-serif;font-size:14px;font-weight:bold;background:${rating === 'minor_correction' ? '#ffffff' : '#111827'};color:${rating === 'minor_correction' ? '#111827' : '#ffffff'};border:1px solid #d4dae3;">${escapeHtml(label)}</a>`;
  }).join('');
  const errorText = run.error_code
    ? `<p style="margin:0 0 10px 0;color:#92400e;font-family:Arial,sans-serif;font-size:13px;"><strong>Review-Grund:</strong> ${escapeHtml(run.error_code)} ${escapeHtml(run.error_message || '')}</p>`
    : '';

  const displayEmail = customerEmail || 'keine@email.com';

  return `
    <div style="border:1px solid #d4dae3;border-radius:8px;padding:16px;margin:0 0 24px 0;background:#f8fafc;">
      <p style="margin:0 0 8px 0;color:#111827;font-family:Arial,sans-serif;font-size:15px;"><strong>Bitte kurz entscheiden</strong></p>
      <p style="margin:0 0 14px 0;color:#475467;font-family:Arial,sans-serif;font-size:13px;line-height:1.5;">Wenn alles passt: <strong>Sendbar</strong>. Wenn Lukas noch etwas &auml;ndern soll: <strong>Korrektur n&ouml;tig</strong>.</p>
      ${errorText}
      ${links}
    </div>
    <div style='max-width:680px;margin:0 auto 20px auto;text-align:left;font-family:Arial,sans-serif;font-size:13px;color:#444;border:1px solid #ccc;background-color:#f4f4f4;padding:10px;border-radius:4px;'>
      <strong>Kunden E-Mail kopieren:</strong><br>
      <span style='user-select:all;-webkit-user-select:all;display:inline-block;background:#fff;padding:4px 8px;margin-top:5px;border:1px solid #bbb;border-radius:3px;cursor:pointer;color:#000;font-weight:bold;'>${escapeHtml(displayEmail)}</span>
    </div>
    ${html}
  `;
}

function buildCleanReviewTable(run) {
  const items = Array.isArray(run.line_items_json) ? run.line_items_json : [];
  if (!items.length) {
    return `<p style="font-family:Arial,sans-serif;font-size:13px;color:#444;text-align:center;">Keine Artikeldaten verf&uuml;gbar.</p>`;
  }

  const rowsHtml = items.map(item => {
    const name = escapeHtml(item.produkt_name_original || item.name || 'Position');
    const net = Number(item.angebot_netto || 0).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return `
      <tr>
        <td style="padding:10px 8px;border-bottom:1px solid #e5e7eb;">${name}</td>
        <td style="padding:10px 8px;border-bottom:1px solid #e5e7eb;text-align:right;">${net} &euro;</td>
      </tr>
    `;
  }).join('');

  const total = Number(run.pricing_json?.gesamt_angebot_brutto || run.summary?.totalGross || 0).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return `
    <table style="width:100%;max-width:680px;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;color:#111827;margin:0 auto;">
      <thead>
        <tr>
          <th style="text-align:left;padding:10px 8px;border-bottom:2px solid #d1d5db;background:#f9fafb;">Produkt</th>
          <th style="text-align:right;padding:10px 8px;border-bottom:2px solid #d1d5db;background:#f9fafb;">Netto</th>
        </tr>
      </thead>
      <tbody>
        ${rowsHtml}
      </tbody>
      <tfoot>
        <tr>
          <td style="padding:12px 8px;font-weight:bold;text-align:right;border-top:2px solid #d1d5db;">Gesamt (Brutto):</td>
          <td style="padding:12px 8px;font-weight:bold;text-align:right;border-top:2px solid #d1d5db;">${total} &euro;</td>
        </tr>
      </tfoot>
    </table>
  `;
}

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
